import { ItemData } from "./routes/CartItem";

export const Products: ItemData[] = [
    {
        description: "Course",
        image: "",
        name: "Course",
        price: 50,
        quantity: 1,
        id: "shoe"
    }
];
